# MS Finance — App (Blog + Alertes + Monday)

## Déploiement (Vercel)

1. Crée un projet Vercel et importe ce dossier.
2. Dans **Settings → Environment Variables**, ajoute :
   - `DISCORD_BOT_TOKEN` = (token de ton bot Discord)
   - `DISCORD_FREE_CHANNEL_ID` = `1365341361217208402`
   - `MONDAY_API_KEY` = (ton token Monday)
3. Déploie.

## Endpoints
- `GET /api/blog` → articles ForexLive (RSS)
- `GET /api/alerts` → derniers messages du canal Discord FREE
- `POST /api/lead` → crée un lead dans le board Monday (LEAD APPLICATION)
- `POST /api/support` → crée un ticket dans le board Monday (support client)

## Board / Colonnes (déjà mappées)
- Leads: `name`, `text_mktn56sf` (email), `text_mktndswj` (tel), `text_mktn5dqb` (capital)
- Support: `name`, `text_mktnnfmg` (email), `text_mktnvxma` (tel), `text_mktnamwk` (message)

## Personnalisation
- Lien partenaire RaiseFX: Header et section VIP (modifier l'URL si besoin).
- Discord public: lien dans le header.

*Note sécurité*: ne mets jamais tes tokens dans le code — utilise les variables d’environnement Vercel.
