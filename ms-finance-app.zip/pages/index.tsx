import { useEffect, useState } from 'react';

const GOLD = '#D4AF37';

type Article = { id: string; title: string; link: string; pubDate?: string };
type Alert = { id: string; content: string; createdAt?: string };

export default function Home() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [lead, setLead] = useState({ name:'', email:'', phone:'', capital:'', notes:'' });
  const [support, setSupport] = useState({ name:'', email:'', phone:'', message:'' });

  useEffect(() => {
    fetch('/api/blog').then(r=>r.json()).then(d => setArticles(d.articles || [])).catch(()=>{});
    fetch('/api/alerts').then(r=>r.json()).then(d => setAlerts(d.alerts || [])).catch(()=>{});
  }, []);

  async function submitLead(e: any) {
    e.preventDefault();
    const r = await fetch('/api/lead', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(lead) });
    const j = await r.json();
    alert(r.ok ? 'Inscription envoyée ✅' : 'Erreur: '+(j.error||'unknown'));
    if (r.ok) setLead({ name:'', email:'', phone:'', capital:'', notes:'' });
  }

  async function submitSupport(e: any) {
    e.preventDefault();
    const r = await fetch('/api/support', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(support) });
    const j = await r.json();
    alert(r.ok ? 'Support envoyé ✅' : 'Erreur: '+(j.error||'unknown'));
    if (r.ok) setSupport({ name:'', email:'', phone:'', message:'' });
  }

  return (
    <div style={{ background:'#000', color:'#eee', minHeight:'100vh', fontFamily:'system-ui, -apple-system, Segoe UI, Roboto, sans-serif' }}>
      <header style={{ position:'sticky', top:0, background:'#000', borderBottom:'1px solid #222', padding:'16px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:28, height:28, border:'2px solid '+GOLD, borderRadius:8 }} />
          <strong style={{ color:GOLD }}>MS Finance</strong>
        </div>
        <nav style={{ display:'flex', gap:12 }}>
          <a href="https://partners.raisefx.com/visit/?bta=167948&brand=raisefx" target="_blank" rel="noreferrer" style={{ background:GOLD, color:'#000', padding:'8px 12px', borderRadius:12, textDecoration:'none' }}>Accès PRO</a>
          <a href="https://discord.gg/xxwuq8RW" target="_blank" rel="noreferrer" style={{ border:'1px solid #444', padding:'8px 12px', borderRadius:12, color:'#ddd', textDecoration:'none' }}>Discord public</a>
        </nav>
      </header>

      <main style={{ maxWidth:1000, margin:'0 auto', padding:'24px', display:'grid', gap:24 }}>
        {/* Blog */}
        <section>
          <h2 style={{ marginBottom:12 }}>📰 Blog économique (ForexLive)</h2>
          <div style={{ display:'grid', gap:12, gridTemplateColumns:'repeat(auto-fit, minmax(260px, 1fr))' }}>
            {articles.map(a => (
              <a key={a.id} href={a.link} target="_blank" rel="noreferrer" style={{ border:'1px solid #222', borderRadius:14, padding:14, background:'#0b0b0b', color:'#eee', textDecoration:'none' }}>
                <div style={{ fontWeight:600, marginBottom:6 }}>{a.title}</div>
                <div style={{ fontSize:12, color:'#aaa' }}>{a.pubDate}</div>
              </a>
            ))}
          </div>
        </section>

        {/* Alerts */}
        <section>
          <h2 style={{ marginBottom:12 }}>🔔 Alertes FREE (Discord)</h2>
          <div style={{ display:'grid', gap:12 }}>
            {alerts.map(m => (
              <div key={m.id} style={{ border:'1px solid #222', borderRadius:14, padding:14, background:'#0b0b0b' }}>
                <div style={{ fontSize:13, color:'#aaa', marginBottom:6 }}>{m.createdAt}</div>
                <div style={{ whiteSpace:'pre-wrap' }}>{m.content}</div>
              </div>
            ))}
            {!alerts.length && <div style={{ color:'#888' }}>Aucune alerte pour l’instant.</div>}
          </div>
        </section>

        {/* Join PRO */}
        <section>
          <h2 style={{ marginBottom:12 }}>👑 Rejoindre le VIP</h2>
          <ol style={{ color:'#bbb', paddingLeft:20, lineHeight:1.6 }}>
            <li>Ouvre le lien partenaire RaiseFX</li>
            <li>Crée ton compte et dépose 500€ minimum</li>
            <li>Reviens ici et contacte le support si besoin</li>
          </ol>
          <a href="https://partners.raisefx.com/visit/?bta=167948&brand=raisefx" target="_blank" rel="noreferrer" style={{ display:'inline-block', marginTop:8, background:GOLD, color:'#000', padding:'10px 14px', borderRadius:12, textDecoration:'none' }}>Lien partenaire RaiseFX</a>
        </section>

        {/* Support */}
        <section>
          <h2 style={{ marginBottom:12 }}>🛟 Support client</h2>
          <form onSubmit={submitSupport} style={{ display:'grid', gap:10, maxWidth:520 }}>
            <input placeholder="Nom" value={support.name} onChange={e=>setSupport(s=>({...s, name:e.target.value}))} required style={inputStyle}/>
            <input placeholder="Email" type="email" value={support.email} onChange={e=>setSupport(s=>({...s, email:e.target.value}))} required style={inputStyle}/>
            <input placeholder="Téléphone" value={support.phone} onChange={e=>setSupport(s=>({...s, phone:e.target.value}))} style={inputStyle}/>
            <textarea placeholder="Message" value={support.message} onChange={e=>setSupport(s=>({...s, message:e.target.value}))} required rows={4} style={inputStyle}/>
            <button type="submit" style={buttonStyle}>Envoyer</button>
          </form>
        </section>

        {/* Register / Lead */}
        <section>
          <h2 style={{ marginBottom:12 }}>📝 S’enregistrer (être rappelé)</h2>
          <form onSubmit={submitLead} style={{ display:'grid', gap:10, maxWidth:520 }}>
            <input placeholder="Nom et prénom" value={lead.name} onChange={e=>setLead(s=>({...s, name:e.target.value}))} required style={inputStyle}/>
            <input placeholder="Téléphone" value={lead.phone} onChange={e=>setLead(s=>({...s, phone:e.target.value}))} required style={inputStyle}/>
            <input placeholder="Email" type="email" value={lead.email} onChange={e=>setLead(s=>({...s, email:e.target.value}))} required style={inputStyle}/>
            <input placeholder="Capital (ex: 500€)" value={lead.capital} onChange={e=>setLead(s=>({...s, capital:e.target.value}))} style={inputStyle}/>
            <textarea placeholder="Notes (objectifs, expérience…)" value={lead.notes} onChange={e=>setLead(s=>({...s, notes:e.target.value}))} rows={3} style={inputStyle}/>
            <button type="submit" style={buttonStyle}>Être rappelé</button>
          </form>
        </section>
      </main>

      <footer style={{ borderTop:'1px solid #222', padding:'16px', fontSize:12, color:'#aaa', textAlign:'center' }}>
        © {new Date().getFullYear()} MS Finance — Tous droits réservés.
      </footer>
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  background:'#0b0b0b', border:'1px solid #222', color:'#eee', padding:'10px 12px', borderRadius:10
};
const buttonStyle: React.CSSProperties = {
  background: GOLD, color:'#000', padding:'10px 12px', border:'none', borderRadius:12, cursor:'pointer', fontWeight:600
};
