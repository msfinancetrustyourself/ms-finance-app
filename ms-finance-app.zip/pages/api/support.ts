import type { NextApiRequest, NextApiResponse } from 'next';

const SUPPORT_BOARD = process.env.MONDAY_BOARD_SUPPORT || '2091810049';
const MONDAY_API_KEY = process.env.MONDAY_API_KEY as string;

// Column IDs provided by you
const COLS = {
  name: 'name',
  email: 'text_mktnnfmg',
  phone: 'text_mktnvxma',
  message: 'text_mktnamwk',
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();
  try {
    if (!MONDAY_API_KEY) return res.status(500).json({ error: 'Missing MONDAY_API_KEY' });
    const { name, email, phone, message } = req.body || {};

    const columnValues: Record<string, any> = {
      [COLS.email]: email || '',
      [COLS.phone]: phone || '',
      [COLS.message]: message || '',
    };

    const itemName = name || email || 'Support';

    const query = `mutation($boardId: ID!, $itemName: String!, $columnValues: JSON!) {
      create_item(board_id: $boardId, item_name: $itemName, column_values: $columnValues) { id }
    }`;

    const r = await fetch('https://api.monday.com/v2', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: MONDAY_API_KEY },
      body: JSON.stringify({ query, variables: { boardId: SUPPORT_BOARD, itemName, columnValues: JSON.stringify(columnValues) } })
    });

    const data = await r.json();
    if (data.errors) return res.status(500).json({ error: data.errors?.map((e:any)=>e.message).join(' | ') });
    res.json({ ok: true, data });
  } catch (e: any) {
    res.status(500).json({ error: e?.message || 'monday_error' });
  }
}
