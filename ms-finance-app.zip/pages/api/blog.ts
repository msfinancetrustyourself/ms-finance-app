import type { NextApiRequest, NextApiResponse } from 'next';
import Parser from 'rss-parser';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const parser = new Parser();
    const feed = await parser.parseURL('https://www.forexlive.com/feed/news/');
    const articles = (feed.items || []).slice(0, 15).map((it: any) => ({
      id: it.link,
      title: it.title,
      link: it.link,
      pubDate: it.pubDate,
    }));
    res.json({ articles });
  } catch (e: any) {
    res.status(500).json({ error: e?.message || 'rss_error' });
  }
}
