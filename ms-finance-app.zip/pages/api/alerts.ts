import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const channelId = process.env.DISCORD_FREE_CHANNEL_ID as string;
    const token = process.env.DISCORD_BOT_TOKEN as string;
    if (!channelId || !token) return res.status(500).json({ error: 'Missing Discord env vars' });

    const r = await fetch(`https://discord.com/api/v10/channels/${channelId}/messages?limit=20`, {
      headers: { Authorization: `Bot ${token}` },
      cache: 'no-store' as any,
    });

    if (!r.ok) {
      const t = await r.text();
      return res.status(500).json({ error: 'discord_error', detail: t });
    }

    const msgs = await r.json();
    const alerts = msgs.map((m: any) => ({
      id: m.id,
      content: m.content,
      createdAt: m.timestamp,
    }));
    res.json({ alerts });
  } catch (e: any) {
    res.status(500).json({ error: e?.message || 'unknown_error' });
  }
}
